kubectl port-forward service/tigera-manager 9443:9443 -n tigera-manager > /dev/null &
kubectl port-forward service/tigera-secure-es-http 9200:9200 -n tigera-elasticsearch > /dev/null &
echo "Port-forwards for tigera-manager and elasticsearch complete"

