#!/bin/bash
set -e

command=$1

if [ "$command" == "set_up" ];then
  echo "##### Set-Up for Lab1: Policy Automation and External Access #####"
  kubectl delete -f ~/labs/FirewallZonesPolicies.yaml &> /dev/null || true
  kubectl delete -f ~/labs/platform.twilio-integration.yaml &> /dev/null || true
  kubectl delete -f ~/labs/platform.allow-apm-access.yaml &> /dev/null || true
  kubectl delete -f ~/labs/platform.legacy-apm-service.yaml &> /dev/null || true
  kubectl apply -f ~/labs/security.pci-whitelist.yaml &> /dev/null || true
  kubectl scale deploy rogue --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy microservice3 --replicas=0 --namespace storefront &> /dev/null || true
  kubectl delete globalnetworkpolicy/compliance.pci-whitelist &> /dev/null || true
  kubectl delete tiers.p/compliance &> /dev/null || true
  kubectl delete stagednetworkpolicy.p $(kubectl get stagednetworkpolicy.p -n storefront --no-headers 2>/dev/null | awk '{print $1}') -n storefront &> /dev/null || true
  echo "Manager UI Login Token for JACK"
  cat ~/labs/jack_token
fi
