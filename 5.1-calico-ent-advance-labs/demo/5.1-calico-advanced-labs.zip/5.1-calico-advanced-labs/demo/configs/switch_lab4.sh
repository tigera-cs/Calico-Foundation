#!/bin/bash
set -e

command=$1

if [ "$command" == "set_up" ];then
  echo "##### Set-Up for Lab4: Host Protection and Microsegmentation #####"
  kubectl delete stagednetworkpolicy.p $(kubectl get stagednetworkpolicy.p -n storefront --no-headers 2>/dev/null | awk '{print $1}') -n storefront &> /dev/null || true
  kubectl delete -f /home/ubuntu/labs/platform.allow-apm-access.yaml &> /dev/null || true
  kubectl delete -f /home/ubuntu/labs/platform.legacy-apm-service.yaml &> /dev/null || true
  kubectl apply -f /home/ubuntu/labs/FirewallZonesPolicies.yaml &> /dev/null || true
  kubectl delete -f /home/ubuntu/labs/platform.twilio-integration.yaml &> /dev/null || true
  kubectl apply -f /home/ubuntu/labs/security.pci-whitelist.yaml &> /dev/null || true
  kubectl scale deploy microservice3 --replicas=1 --namespace storefront &> /dev/null || true
  kubectl scale deploy rogue --replicas=0 --namespace storefront &> /dev/null || true
  kubectl delete globalnetworkpolicy/compliance.pci-whitelist &> /dev/null || true
  HEP=$(kubectl get hostendpoint --no-headers | awk '{print $1}')
  echo "Access the legacy APM service at: ${HEP}.SUBDOMAIN"
fi
