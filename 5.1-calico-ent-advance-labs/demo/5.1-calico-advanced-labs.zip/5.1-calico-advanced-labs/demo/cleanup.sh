kubectl delete -f stage2/rogue.yaml 2> /dev/null

