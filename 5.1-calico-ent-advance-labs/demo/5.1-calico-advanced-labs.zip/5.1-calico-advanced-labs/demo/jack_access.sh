#!/bin/bash
set -e

TIER_UI_USER=jack
CLUSTER_NAMESPACE=tigera-access

echo "[INFO] Creating Default Tier Role for ${TIER_UI_USER}"
kubectl apply -f ./jack_rbac.yaml || true

echo "[INFO] Retrieve  Calico Enterprise Manager token"
SECRET_NAME=$(kubectl get secrets -n ${CLUSTER_NAMESPACE} | grep ${TIER_UI_USER}-token | awk 'FNR == 1 {print $1}')
TOKEN=$(kubectl get secret -n ${CLUSTER_NAMESPACE} "${SECRET_NAME}" -o jsonpath='{.data.token}' | base64 --decode)

echo "[INFO] Populating Trial Instructions"
echo ${TOKEN} > ./configs/labs/jack_token
