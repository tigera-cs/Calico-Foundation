#!/bin/bash

set -e

export KUBECONFIG=/root/.kube/config
export PRIVATE_IP=$(hostname -i)
export PUBLIC_IP=$(curl ipinfo.io/ip)
export INTERFACE=$(ip route | grep default | sed -e "s/^.*dev.//" -e "s/.proto.*//")

touch /tmp/set_up

echo "[INFO] Sleeping for 60 second" | tee /tmp/set_up
sleep 60

echo "[INFO] Creating Kubeconfig"
cat > /root/.kube/config <<EOF
KUBECONTENTS
EOF

echo "[INFO] Creating HEP" | tee /tmp/set_up
cat > /root/my_hep.yaml <<EOF
apiVersion: projectcalico.org/v3
kind: HostEndpoint
metadata:
  name: ${HOSTNAME}
  labels:
    name: legacy-apm-service
    environment: tigera-trial
spec:
  expectedIPs:
  - ${PUBLIC_IP}
  - ${PRIVATE_IP}
  interfaceName: ${INTERFACE}
  node: ${HOSTNAME}

EOF

echo "[INFO] Restart Services" | tee /tmp/set_up
systemctl restart calico-felix.service || true
systemctl stop nginx.service || true
systemctl restart vaping.service || true
systemctl stop kubelet.service || true
systemctl stop docker.service || true
rm -rf /home/vaibhavthakur || true

echo "[INFO] Applying HEP" | tee /tmp/set_up
kubectl apply -f /root/my_hep.yaml || true

echo "[INFO] START-UP DONE" | tee /tmp/set_up
