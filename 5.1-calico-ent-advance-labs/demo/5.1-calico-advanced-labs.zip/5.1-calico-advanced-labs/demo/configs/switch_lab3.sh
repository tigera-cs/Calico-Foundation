#!/bin/bash
set -e

command=$1

if [ "$command" == "set_up" ];then
  echo "##### Implementing Existing Security Controls in Kubernetes #####"
  kubectl delete stagednetworkpolicy.p $(kubectl get stagednetworkpolicy.p -n storefront --no-headers 2>/dev/null | awk '{print $1}') -n storefront &> /dev/null || true  
  kubectl delete -f ~/labs/FirewallZonesPolicies.yaml &> /dev/null || true
  kubectl apply -f ~/labs/platform.twilio-integration.yaml &> /dev/null || true
  kubectl scale deploy rogue --replicas=0 --namespace storefront &> /dev/null || true
  kubectl delete -f ~/labs/security.pci-whitelist.yaml &> /dev/null || true
  kubectl delete -f ~/labs/platform.allow-apm-access.yaml &> /dev/null || true
  kubectl delete -f ~/labs/platform.legacy-apm-service.yaml &> /dev/null || true
  kubectl label -n storefront sa/storefront PCI="true" &> /dev/null || true
  kubectl scale deploy microservice1 --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy microservice2 --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy microservice3 --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy logging --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy frontend --replicas=0 --namespace storefront &> /dev/null || true
  kubectl scale deploy backend --replicas=0 --namespace storefront &> /dev/null || true
  sleep 2
  echo "Set-Up in progress ..."
  sleep 3
  kubectl scale deploy microservice1 --replicas=1 --namespace storefront &> /dev/null || true
  kubectl scale deploy microservice2 --replicas=1 --namespace storefront &> /dev/null || true
  kubectl scale deploy logging --replicas=1 --namespace storefront &> /dev/null || true
  kubectl scale deploy frontend --replicas=1 --namespace storefront &> /dev/null || true
  kubectl scale deploy backend --replicas=1 --namespace storefront &> /dev/null || true
  sleep 8
fi
