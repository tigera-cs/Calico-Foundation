#!/bin/bash
set -e

command=$1

echo "##### Set-Up for Lab2: Visibility and Troubleshooting Successfully Complete #####"
kubectl delete stagednetworkpolicy.p $(kubectl get stagednetworkpolicy.p -n storefront --no-headers 2>/dev/null | awk '{print $1}') -n storefront &> /dev/null || true
kubectl apply -f ~/labs/FirewallZonesPolicies.yaml &> /dev/null || true
kubectl apply -f ~/labs/platform.twilio-integration.yaml &> /dev/null || true
kubectl apply -f ~/labs/security.pci-whitelist.yaml &> /dev/null || true

if [ "$command" == "deploy_rogue" ];then
	echo "Deployent of Rogue Pod for Lab2 complete"
	kubectl apply -f ~/labs/FirewallZonesPolicies.yaml &> /dev/null || true 
	kubectl apply -f ~/labs/platform.twilio-integration.yaml &> /dev/null || true 
	kubectl apply -f ~/labs/security.pci-whitelist.yaml &> /dev/null || true
	kubectl scale deploy rogue --replicas=1 --namespace storefront &> /dev/null || true
fi

kubectl scale deploy microservice3 --replicas=0 --namespace storefront &> /dev/null || true
kubectl delete globalnetworkpolicy/compliance.pci-whitelist &> /dev/null || true
kubectl delete tiers.p/compliance &> /dev/null || true
kubectl delete -f ~/labs/platform.allow-apm-access.yaml &> /dev/null || true
kubectl delete -f ~/labs/platform.legacy-apm-service.yaml &> /dev/null || true