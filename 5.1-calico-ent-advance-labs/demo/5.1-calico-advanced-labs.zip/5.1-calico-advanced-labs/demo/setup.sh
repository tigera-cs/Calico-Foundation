#!/bin/bash

#echo [INFO] Create Labs User
#kubectl apply -f ./rbac.yaml

echo [INFO] Pre-req for Lab 1
kubectl create ns tigera-access || true
kubectl apply -f ./jack_rbac.yaml || true
./jack_access.sh || true 

#echo [INFO] Pre-req for Lab 4
#./lab4.sh

#echo [INFO] Update Microservice3 Manifest
#yq write -i stage1/microservice3.yaml spec.template.spec.containers[0].env[0].value ${LABS_CLUSTER_NAME}-legacy-apm-service.try.tigera.io

echo [INFO] Patch Felix Configuration
kubectl patch felixconfiguration.p default -p '{"spec":{"flowLogsFileAggregationKindForAllowed":1,"flowLogsFlushInterval":"30s"}}'

echo [INFO] Create Policies
kubectl apply -f stage0
sleep 2

echo [INFO] Create Workloads
kubectl apply -f stage1
kubectl apply -f stage2/rogue.yaml
sleep 2

echo [INFO] Create compliance Reports and Other Policies
kubectl apply -f stage2/feodo-block-policy.yaml
kubectl apply -f stage2/FirewallZonesPolicies.yaml
kubectl apply -f stage2/restricted-resource-allow-policy.yaml
kubectl apply -f stage2/compliance-reports.yaml --validate=false
sleep 2

# Get the compliance reporter token and use our template to generate the reporter pod yamls
COMPLIANCE_REPORTER_TOKEN=$(kubectl get secrets -n tigera-compliance | grep tigera-compliance-reporter-token* | awk 'FNR == 1 {print $1}')
sed -e "s?<COMPLIANCE_REPORTER_TOKEN>?$COMPLIANCE_REPORTER_TOKEN?g" stage2/compliance-reporter-pods-template.yaml > stage2/compliance-reporter-pods.yaml
kubectl apply -f stage2/compliance-reporter-pods.yaml

kubectl get tigerastatus


