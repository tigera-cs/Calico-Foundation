#!/bin/bash

/bin/lab1 set_up && echo "Lab1 Set-up OK" || echo "Lab1 Setup Failed"
/usr/bin/ttyd --ssl --ssl-cert /ttyd-certs/server.crt --ssl-key /ttyd-certs/server.key -p 8443 login