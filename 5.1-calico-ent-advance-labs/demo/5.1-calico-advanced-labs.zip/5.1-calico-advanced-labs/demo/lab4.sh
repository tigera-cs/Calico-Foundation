#!/bin/bash

set -e

echo "Using ${KUBECONFIG} for kubectl access"

echo "************** Configure Lab4 HEP Start-Up ***************"
sed -i -e "/KUBECONTENTS/{r $KUBECONFIG" -e "d}" ./lab4_startup.sh

echo "************** Create Lab4 HEP ***************"
gcloud beta compute --project=tigera-cea instances create ${LABS_CLUSTER_NAME}-legacy-apm-service --zone=us-central1-a --machine-type=e2-medium --subnet=default --image=lab4-base-06 --image-project=tigera-cea --boot-disk-size=200GB --metadata-from-file startup-script=./lab4_startup.sh
