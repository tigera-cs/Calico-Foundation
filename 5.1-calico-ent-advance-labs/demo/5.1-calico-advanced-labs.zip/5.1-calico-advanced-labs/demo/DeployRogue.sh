#!/usr/bin/env bash
set +x
kubectl apply -f ./stage2/rogue.yaml> /dev/null 2>&1

sleep 15
curl -X POST -H "Content-type: application/json"  \
https://hooks.slack.com/services/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 \
--data '
{
    "attachments": [
        {
            "pretext": "Tigera Secure Anomaly Detection",
            "title": "Port Scan - Pods: Count of destination ports compared with all pods",
            "title_link": "https://127.0.0.1:9443/policies/tiered",
            "text": "Actual count of 1024 compared with typical value of 1.7794882042577096",
            "color": "#7CD197"
        }
    ]
}
'

ELASTIC_AUTH=$(kubectl -n tigera-elasticsearch get secret tigera-secure-es-elastic-user -o yaml | grep elastic: | awk '{print $2}' | base64 --decode)
cat stage2/anomalies.json | curl -k -u "elastic:$ELASTIC_AUTH" -X PUT -H "Content-Type: application/json" -d "$(</dev/stdin)"  https://127.0.0.1:9200/tigera_secure_ee_events.cluster/_doc/anomaly_detection-1564685400-600-port_scan_pods-0-""-"rogue-hr2v9e"-"" > /dev/null &
